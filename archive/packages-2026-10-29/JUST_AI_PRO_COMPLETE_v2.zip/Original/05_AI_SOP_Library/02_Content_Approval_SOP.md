# Social Content Approval SOP

**Owner:** Content owner; approval by store manager.

1. Select a post with a clear customer benefit.
2. Use your own licensed images and actual product details.
3. Draft caption using AI prompts if helpful.
4. Check product name, pricing, availability, promotions and policy statements.
5. Confirm any testimonials and permission to publish them.
6. Publish manually or schedule only approved content.
7. Review relevant engagement without overinterpreting small samples.

**Stop conditions:** Unverified discount claims, missing rights to images, stale price list, or sensitive customer content.
