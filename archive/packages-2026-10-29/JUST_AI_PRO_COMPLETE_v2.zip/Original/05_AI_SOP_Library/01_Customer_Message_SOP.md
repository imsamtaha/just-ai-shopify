# Customer Message SOP

## Purpose
Respond quickly and accurately to **inbound** customer messages.

## Owner
Store manager or explicitly appointed staff member.

## Inputs
Verified price list, active product catalogue, inventory and shipping policy.

## Steps
1. Read the question carefully; identify what the customer is requesting.
2. Check facts in the approved store source.
3. Choose one matching WhatsApp template from the original kit or the Notion CSV.
4. Fill all `[placeholders]` with verified data.
5. Confirm tone, price, currency, size, delivery and exchange details.
6. Send **once** via the approved business account and record the outcome.

## Escalation
If facts are missing, tell the customer you are checking. Do not promise availability.
