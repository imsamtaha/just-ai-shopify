# Order Handling SOP

**Trigger:** A valid paid order, verified in Shopify or the business's authorized payment system.

1. Check order ID and payment status, taking care not to expose sensitive payment data.
2. Confirm actual stock and variant.
3. Create a private fulfillment task.
4. Check the shipping instructions and delivery estimate before sharing them.
5. Update order tracking and follow approved refund/return policies.
6. If a discrepancy exists, hold fulfillment until owner review.

**Do not assume a draft order, screenshot or customer claim is proof of payment.**
