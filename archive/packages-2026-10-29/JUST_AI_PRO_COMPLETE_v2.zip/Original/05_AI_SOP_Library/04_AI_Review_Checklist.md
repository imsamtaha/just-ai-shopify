# AI Output Review Checklist

Before using AI-generated copy, check:

- [ ] All claims supported by current store data
- [ ] Prices and currency correct
- [ ] Product variations accurate
- [ ] No invented guarantees, testimonials, or sales results
- [ ] No personal customer information disclosed
- [ ] Friendly and clear language for target market
- [ ] Human approval recorded for outbound posts and messages

**When uncertain:** Ask for missing information instead of guessing.
