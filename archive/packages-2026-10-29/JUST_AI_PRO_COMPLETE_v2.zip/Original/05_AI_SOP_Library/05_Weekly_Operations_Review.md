# Weekly Operations Review

**Time box:** About 20 minutes; adjust to store size.

| Metric | Value | Source |
|---|---|---|
| Inquiries | [number] | Approved tracker |
| Verified paid orders | [number] | Shopify/authorized order log |
| Refunds and returns | [number] | Order log |
| Unresolved questions | [number] | Customer inbox |
| Posts published | [number] | Instagram |

## Review decisions
1. Identify one recurring customer question to turn into an FAQ.
2. Check one bottleneck with a high impact on service.
3. Assign an action to a named owner and a due date.
4. Update workflow or automation status only after verifying actual changes.

**Note:** Never mistake demo/example rows for real store performance.
