# JUST AI SALES KIT PRO | START HERE

**A practical, editable AI-powered sales operating kit** for small online businesses and freelance sellers.

**What you receive**
1. The complete original Sales Kit: 50 WhatsApp replies, 30 Instagram content ideas, 12 AI prompts, and an editable customer tracker.
2. A **Notion-ready workspace**, provided as Markdown pages and CSV databases that you import into your own Notion account.
3. Eight documented sales workflows, six automation blueprints, SOPs, and starter JavaScript utilities.

**Important:** This is a *template toolkit*, not a hosted software service. Notion pages and databases must be imported by the buyer. Automation blueprints do **not** execute automatically; external accounts, integrations, configuration and testing may be necessary. Some platforms have paid plans. No sales or time-saving results are guaranteed.

## Start in 15 minutes
1. Unzip the archive and open `01_Original_Sales_Kit/00_START_HERE.pdf`.
2. Import `02_Notion_Import/00_JUST_AI_HOME.md` into Notion as a page. Import each CSV file as a separate Notion database. Notion import options vary by device and plan; use a desktop-class browser if the mobile app does not expose Import.
3. Copy the 8 playbooks into pages under your workspace, or link them manually.
4. Replace all DEMO rows, placeholder brackets and example policy terms with real business information before use.
5. Open the original Excel tracker if you prefer spreadsheets. Never paste confidential customer information into public AI chats.

## Sell responsibly
- Obtain permission before sending WhatsApp or email marketing.
- Verify prices, stock, delivery details and exchange policies manually.
- Use AI as a draft assistant, not as a substitute for accurate store records.
- Review tool access and customer privacy requirements before enabling any automated action.

**Version:** 1.0 • October 2026 • JUST AI
