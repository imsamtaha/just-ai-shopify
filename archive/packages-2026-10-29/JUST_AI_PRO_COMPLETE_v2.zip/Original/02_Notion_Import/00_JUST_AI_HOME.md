# JUST AI | Sales & Automation Command Center

> YOUR SALES OPERATING SYSTEM
>
> Built for small businesses. Fill the databases with verified data before using them with customers.

## Quick Dashboard
- **Today's focus:** Reply to new inquiries, confirm pending orders, and schedule one useful Instagram post.
- **Sales pipeline:** Use the existing `04_Customer_Tracker.xlsx` from the original kit or your own compliant CRM.
- **AI assistant:** Open the 12 prompts in `01_Original_Sales_Kit/03_AI_Prompts_12.docx`.

## Workflows
**Capture the process. Define the trigger, steps and owner. Track tools, inputs, outputs, status and review date.**

Import `01_Workflows.csv` as a database; use the detailed playbooks from `03_Workflow_Playbooks` for each workflow.

## Automations
**What should run without manual work? Specify the conditions, approved actions, owners and safeguards.**

Import `02_Automations.csv`. Start every automation in **Draft** or **Test** until reviewed. Never activate customer messaging without consent and verification.

## Templates
**Reusable prompts, SOPs, replies and marketing starter content.**

Import `03_Templates.csv`. For the original full library use the 50 WhatsApp templates and 30 Instagram posts in the original kit.

## Tools & Stack
**What the kit relies on, where data lives, and which integrations require separate accounts.**

Import `04_Tools_and_Stack.csv`. Record credential owners without putting passwords or API keys into Notion.

## Ideas & Backlog
**Capture new workflow ideas. Rate their impact and difficulty. Test small before scaling.**

Import `05_Ideas_and_Backlog.csv`.

## Weekly review (20 minutes)
- [ ] Clear inquiries or mark why they are blocked
- [ ] Verify prices and stock in any scheduled posts
- [ ] Review orders, returns and delivery updates
- [ ] Update workflow statuses and automation error log
- [ ] Select one improvement for the next week

---
**Buyer setup notice:** Notion import is manual; importing a CSV creates a database but does not auto-link it into this Home page. Add links/views in Notion after importing.
