# Code utilities (optional)

Three small CommonJS JavaScript snippets are included for **manual/test-mode code steps** in Node.js-compatible environments:

1. Normalize a lead record while preserving marketing-consent status.
2. Flag duplicate order references before importing data.
3. Generate a WhatsApp draft URL with explicit human approval. It does **not** send a message.

The scripts use no external dependencies, secrets or network calls. Run `node 01_normalize_lead.js` etc. with Node.js 18+ as a demo. To adapt to Make, Zapier or Pipedream, follow that platform's code-step input/output conventions. They are examples, not plug-and-play integrations.

**Security:** Do not store API keys in scripts or this Notion workspace. Use your automation platform's secret manager.
