# 06. Post-delivery feedback

**Category:** Customer success  
**Outcome:** Collect helpful customer feedback  
**Trigger:** Delivery confirmed  
**Owner:** Store owner  
**Suggested tools:** WhatsApp; tracker  
**Inputs:** Delivery confirmation, consent  
**Expected output:** Feedback log  
**Status:** Draft template  
**Next review:** 2026-11-05

## Standard procedure
1. **Check permissions**. Record what you checked and the actual result.
2. **ask politely**. Record what you checked and the actual result.
3. **log outcome**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
