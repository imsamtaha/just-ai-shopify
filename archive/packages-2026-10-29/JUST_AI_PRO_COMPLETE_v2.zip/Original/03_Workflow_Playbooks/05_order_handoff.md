# 05. Order handoff

**Category:** Operations  
**Outcome:** Avoid missed deliveries  
**Trigger:** Payment confirmed  
**Owner:** Store owner  
**Suggested tools:** Shopify; tracker  
**Inputs:** Verified order, delivery area  
**Expected output:** Handoff checklist  
**Status:** Draft template  
**Next review:** 2026-11-04

## Standard procedure
1. **Verify order**. Record what you checked and the actual result.
2. **confirm address**. Record what you checked and the actual result.
3. **create packing task**. Record what you checked and the actual result.
4. **notify team**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
