# 03. Opt-in follow-up

**Category:** Retention  
**Outcome:** Respond to opted-in prospects  
**Trigger:** Customer requested follow-up  
**Owner:** Store owner  
**Suggested tools:** Tracker; WhatsApp  
**Inputs:** Recorded opt-in, inquiry context  
**Expected output:** One contextual follow-up  
**Status:** Draft template  
**Next review:** 2026-11-03

## Standard procedure
1. **Check consent**. Record what you checked and the actual result.
2. **check status**. Record what you checked and the actual result.
3. **customize**. Record what you checked and the actual result.
4. **approve**. Record what you checked and the actual result.
5. **send**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
