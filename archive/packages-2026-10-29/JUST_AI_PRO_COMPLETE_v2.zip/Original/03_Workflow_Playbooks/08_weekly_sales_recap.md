# 08. Weekly sales recap

**Category:** Management  
**Outcome:** Understand bottlenecks  
**Trigger:** Weekly review  
**Owner:** Store owner  
**Suggested tools:** Tracker; Notion  
**Inputs:** Verified sales records  
**Expected output:** Weekly recap  
**Status:** Draft template  
**Next review:** 2026-11-06

## Standard procedure
1. **Aggregate inquiries**. Record what you checked and the actual result.
2. **count orders**. Record what you checked and the actual result.
3. **review refunds**. Record what you checked and the actual result.
4. **list next actions**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
