# 07. Low stock check

**Category:** Inventory  
**Outcome:** Avoid selling unavailable stock  
**Trigger:** Stock review time  
**Owner:** Store owner  
**Suggested tools:** Inventory sheet  
**Inputs:** Stock thresholds, counts  
**Expected output:** Owner action list  
**Status:** Draft template  
**Next review:** 2026-11-05

## Standard procedure
1. **Review inventory**. Record what you checked and the actual result.
2. **flag items**. Record what you checked and the actual result.
3. **update listing**. Record what you checked and the actual result.
4. **alert owner**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
