# 01. New WhatsApp inquiry

**Category:** Customer service  
**Outcome:** Provide accurate first reply  
**Trigger:** New inbound message  
**Owner:** Store owner  
**Suggested tools:** WhatsApp; tracker  
**Inputs:** Customer question, SKU, available stock  
**Expected output:** Accurate reply and inquiry log  
**Status:** Draft template  
**Next review:** 2026-11-02

## Standard procedure
1. **Verify product**. Record what you checked and the actual result.
2. **check stock**. Record what you checked and the actual result.
3. **reply**. Record what you checked and the actual result.
4. **log result**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
