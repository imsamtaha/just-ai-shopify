# 02. Product question to quote

**Category:** Sales  
**Outcome:** Give verified product details  
**Trigger:** Buyer asks for price or size  
**Owner:** Store owner  
**Suggested tools:** Inventory; WhatsApp  
**Inputs:** SKU, size, color, shipping location  
**Expected output:** Quote with conditions  
**Status:** Draft template  
**Next review:** 2026-11-02

## Standard procedure
1. **Check SKU**. Record what you checked and the actual result.
2. **validate variants**. Record what you checked and the actual result.
3. **send details**. Record what you checked and the actual result.
4. **offer ordering next step**. Record what you checked and the actual result.

## Quality checklist
- [ ] Customer-specific facts verified
- [ ] No unauthorized bulk messaging
- [ ] No personal data shared in public AI tools
- [ ] Exceptions sent for manual review
- [ ] Action and outcome recorded

## Failure and recovery
If a detail is missing or a connector fails, **stop and ask the owner to verify**. Never invent the data or retry a customer-facing send blindly.

## Metrics to track
- Number of relevant cases this week
- Cases resolved and cases blocked
- Errors or corrections required

**Implementation note:** This is a documented workflow, not a deployed automation.
