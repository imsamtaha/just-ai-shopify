# Delivery acceptance checklist

This is an onboarding document, not the completed custom design.
هذا ملف بدء المشروع وليس التصميم النهائي.

- [ ] Logo & Brand Identity service matches the agreed brief.
- [ ] Responsive one-page website service matches the agreed brief.
- [ ] Five coordinated social post designs matches the agreed brief.
- [ ] Agreed handover and acceptance review matches the agreed brief.
- [ ] Spelling, contact details, URLs and languages checked.
- [ ] Files open in the agreed formats and dimensions.
- [ ] Usage rights and any third-party costs documented.
- [ ] Agreed revisions completed and handover accepted in writing.

راجع الأسماء والروابط واللغات وصيغ الملفات والحقوق والتعديلات المتفق عليها قبل قبول التسليم.
