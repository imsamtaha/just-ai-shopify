# Business Launch Pack — project brief

Complete in English or Arabic. Send only the information needed to scope the work. Do not include passwords, payment details or private customer data.
يمكن تعبئة النموذج بالعربية أو الإنجليزية. لا ترسل كلمات مرور أو بيانات دفع أو معلومات عملاء خاصة.

## Business name, audience and launch goal
Your answer / إجابتك:

## Brand direction and required languages
Your answer / إجابتك:

## Website copy, images and call-to-action links
Your answer / إجابتك:

## Five approved social post texts and dimensions
Your answer / إجابتك:

## Domain/hosting arrangements and target date to discuss
Your answer / إجابتك:

## Agreement record / سجل الاتفاق
Scope: 
Revision allowance: 
File formats and source handover: 
Delivery date: 
Dependencies from customer: 
Additional costs: 
Written approval: 

Leave these fields open until agreed with JUST AI before purchase.
اترك بنود الاتفاق مفتوحة حتى تأكيدها كتابياً قبل الشراء.
