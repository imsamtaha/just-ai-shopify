# Social Media Design Pack — project brief

Complete in English or Arabic. Send only the information needed to scope the work. Do not include passwords, payment details or private customer data.
يمكن تعبئة النموذج بالعربية أو الإنجليزية. لا ترسل كلمات مرور أو بيانات دفع أو معلومات عملاء خاصة.

## Business and campaign goal
Your answer / إجابتك:

## Five approved post texts
Your answer / إجابتك:

## Brand logo, colours and image permissions
Your answer / إجابتك:

## Platform and dimensions for each post
Your answer / إجابتك:

## Preferred direction and examples
Your answer / إجابتك:

## Agreement record / سجل الاتفاق
Scope: 
Revision allowance: 
File formats and source handover: 
Delivery date: 
Dependencies from customer: 
Additional costs: 
Written approval: 

Leave these fields open until agreed with JUST AI before purchase.
اترك بنود الاتفاق مفتوحة حتى تأكيدها كتابياً قبل الشراء.
