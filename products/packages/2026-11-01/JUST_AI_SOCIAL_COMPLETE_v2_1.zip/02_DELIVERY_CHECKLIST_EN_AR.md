# Delivery acceptance checklist

This is an onboarding document, not the completed custom design.
هذا ملف بدء المشروع وليس التصميم النهائي.

- [ ] Five coordinated custom post designs matches the agreed brief.
- [ ] Approved branding and content matches the agreed brief.
- [ ] Image exports in agreed dimensions matches the agreed brief.
- [ ] Spelling, contact details, URLs and languages checked.
- [ ] Files open in the agreed formats and dimensions.
- [ ] Usage rights and any third-party costs documented.
- [ ] Agreed revisions completed and handover accepted in writing.

راجع الأسماء والروابط واللغات وصيغ الملفات والحقوق والتعديلات المتفق عليها قبل قبول التسليم.
