# Campaign brief / موجز الحملة

Make a working copy. Complete every field using real facts before generating copy.
انسخ النموذج واملأ الحقول بحقائق فعلية قبل صياغة المحتوى.

| Field / الحقل | Your answer / إجابتك |
|---|---|
| Business / النشاط | |
| One audience / جمهور محدد | |
| Problem they recognize / المشكلة | |
| One offer and exact contents / العرض ومحتوياته | |
| Price and currency / السعر والعملة | |
| Evidence you can show / دليل قابل للعرض | |
| What is excluded / غير المشمول | |
| One next action / الخطوة المطلوبة | |
| Channel and owner / القناة والمسؤول | |
| Start/end and review date / المدة والمراجعة | |
| Budget ceiling you approve / سقف الإنفاق | |
| Success metric / مقياس النجاح | |
| Current baseline / الوضع الحالي | |
| Hypothesis, not promise / الفرضية وليست وعداً | |

## Fictional completed brief / مثال خيالي
Business: Cedar Desk, a fictional slide-design studio.
Audience: founders reviewing a pitch presentation themselves.
Problem: crowded slides hide the main message.
Offer: a self-service editable slide review checklist with a worked example.
Example price: USD 9. This is not a price for a JUST AI product.
Proof: demonstrate three checks on a fictional slide with before/after captions.
Excluded: slide redesign, fundraising advice, client-specific feedback.
CTA: read the exact checklist contents on the product page.
Channel: organic Instagram. Owner: studio owner. Period: 30 days.
Budget: zero ad spend in this example. Staff time still has a cost.
Metric: qualified inquiries from people who understand the self-service scope.
Baseline: unknown. First week establishes a baseline, not a guaranteed target.
Hypothesis: clearer demonstrations may improve understanding of the offer.

المثال: استوديو خيالي يساعد المؤسسين على مراجعة شرائحهم بأنفسهم. العرض قائمة مراجعة رقمية بسعر تجريبي 9 دولارات، لا خدمة تصميم. الدليل عرض تطبيقي على شريحة خيالية. القناة إنستغرام دون إعلانات مدفوعة. مقياس النجاح استفسارات مناسبة تفهم حدود العرض. الفرضية قابلة للاختبار ولا تضمن نتيجة.
