# Copy canvas / مخطط النص

Use one canvas per asset. Write short, concrete answers.
1. Audience / الجمهور: Who should recognize themselves?
2. Problem / المشكلة: What specific task is difficult?
3. Useful step / الخطوة: What can the reader do now?
4. Evidence / الدليل: What can you actually show or substantiate?
5. Offer / العرض: What exact files or service are included?
6. Limitation / القيد: What should the buyer not expect?
7. Action / الدعوة: What is one useful next step?
8. Review / المراجعة: Are price, claims, links, translation and permissions correct?

## Fictional completed example / مثال خيالي
Audience: a founder reviewing a short pitch deck.
Problem: multiple messages compete on one slide.
Step: write the single sentence the audience should remember.
Evidence: a labelled fictional slide before and after changing the heading.
Offer: editable checklist and worked example.
Limitation: no redesign service or fundraising guarantee.
Action: read the checklist contents before buying.

EN draft: A crowded slide can hide your main idea. Write the one sentence your audience should remember, then make it the heading. See our fictional before-and-after example. Need a repeatable review process? Read the checklist contents to check whether the self-service format fits your work.

AR draft: قد تخفي الشريحة المزدحمة فكرتك الرئيسية. اكتب الجملة التي تريد أن يتذكرها الجمهور واجعلها العنوان. شاهد المثال الخيالي قبل التعديل وبعده. تحتاج إلى خطوات مراجعة متكررة؟ اقرأ محتويات القائمة لتتأكد من أن صيغة الاستخدام الذاتي تناسبك.
