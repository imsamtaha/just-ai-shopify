# 12 paired AI prompts / ١٢ توجيهاً باللغتين

For every prompt, paste your completed brief and relevant approved facts. Replace placeholders. Ask the tool to list missing facts. Remove personal data. These prompts draft text; they do not publish, send or launch ads.

لكل توجيه، أرفق موجزك والحقائق المعتمدة فقط واحذف البيانات الشخصية. راجع الناتج قبل الاستخدام.

## 1. Audience

EN: Using only this brief, describe one audience, three likely questions and the assumptions that still need validation. Do not invent research.

AR: استناداً إلى الموجز فقط، صف جمهوراً واحداً وثلاثة أسئلة محتملة والافتراضات التي تحتاج تحققاً. لا تختلق بحثاً.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 2. Offer clarity

EN: Rewrite this offer as audience, job, deliverables, requirements and exclusions. Keep the exact price and flag contradictions.

AR: أعد صياغة العرض إلى جمهور ومهمة ومخرجات ومتطلبات واستثناءات. حافظ على السعر وأظهر التناقضات.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 3. Content pillars

EN: Suggest three content themes linked to the audience problem. Give two factual post ideas per theme; identify facts I must supply.

AR: اقترح ثلاثة محاور مرتبطة بمشكلة الجمهور وفكرتين لكل محور. حدد الحقائق التي يجب أن أزوّدك بها.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 4. Calendar

EN: Turn these approved themes into a 30-day draft calendar. Include topic, format, one CTA, evidence needed and owner. Avoid repetitive sales posts.

AR: حوّل المحاور المعتمدة إلى مسودة تقويم 30 يوماً مع الموضوع والصيغة ودعوة واحدة والدليل المطلوب والمسؤول.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 5. Educational caption

EN: Draft a helpful caption from these verified facts. Structure it as problem, practical step and one invitation. No unsupported promises.

AR: اكتب نصاً مفيداً من الحقائق المؤكدة: مشكلة وخطوة عملية ودعوة واحدة دون وعود غير موثقة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 6. Bilingual adaptation

EN: Adapt this approved English caption into natural Arabic without changing numbers, offer terms or limitations. List ambiguous phrases.

AR: كيّف النص الإنجليزي المعتمد إلى عربية طبيعية دون تغيير الأرقام والشروط والقيود، وحدد العبارات الغامضة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 7. Demonstration script

EN: Write a 30-second demonstration script using this actual process. Include shot, spoken line, on-screen label and evidence. Label fictional data DEMO.

AR: اكتب سيناريو عرض مدته 30 ثانية من الخطوات الفعلية مع اللقطة والجملة والنص المرئي والدليل. علّم البيانات الخيالية كتجريبية.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 8. FAQ

EN: Draft five FAQs using only the supplied product facts. Answer unknowns with a question for the owner rather than an invented policy.

AR: صغ خمسة أسئلة شائعة من معلومات المنتج فقط. عند غياب الإجابة، وجّه سؤالاً للمالك ولا تختلق سياسة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 9. Landing page

EN: Create a concise page outline: buyer problem, contents, demonstration, requirements, delivery and CTA. Use only provided proof.

AR: اكتب مخطط صفحة موجزاً: مشكلة العميل والمحتويات والعرض والمتطلبات والتسليم والدعوة، باستخدام الدليل المقدم فقط.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 10. Opt-in follow-up

EN: Draft one low-pressure follow-up to this customer who asked for a reminder. Use anonymous context, confirm current facts and include an easy way to decline.

AR: اكتب متابعة واحدة دون ضغط لعميل طلب تذكيراً. استخدم سياقاً مجهول الهوية وحقائق حديثة وخياراً واضحاً لرفض المتابعة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 11. Experiment

EN: Turn this question into a test with one changed variable, a metric, equal review windows and conditions that would make the comparison unreliable.

AR: حوّل السؤال إلى تجربة بمتغير واحد ومقياس وفترات متساوية، وحدد ما يجعل المقارنة غير موثوقة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.

## 12. Review

EN: Review these aggregate results. Separate observation from explanation, flag missing data and suggest one next test. Do not claim causality from a small sample.

AR: راجع النتائج المجمعة وافصل الملاحظة عن التفسير، وحدد البيانات الناقصة واقترح اختباراً واحداً دون استنتاج سببية من عينة صغيرة.

Input: [completed brief] + [approved facts]. Output: draft + missing facts + review checklist.