# AI Marketing Toolkit — tutorial transcript

English synthetic narration. Arabic written translation below each step. Original instructional slide video; fictional examples. Version 2.0, 29 October 2026.

## 1. Write a specific campaign brief

Open 01_CAMPAIGN_BRIEF.md. Fill the audience, problem, offer, verified proof, channel, call to action and budget ceiling. The fictional Cedar Desk example sells a slide review checklist. Pick one goal, such as qualified product-page visits, and separate your target from an actual result.

افتح موجز الحملة وحدد الجمهور والمشكلة والعرض والدليل والقناة والدعوة والإطار المالي. اختر هدفاً واحداً وافصل المستهدف عن النتيجة الفعلية.

## 2. Plan the month in the workbook

Open 02_CAMPAIGN_WORKBOOK.xlsx. Read Start, then fill Brief and Calendar. Thirty suggested angles are provided, with editable dates, captions, calls to action, owners and status. Choose the angles that fit your offer; you do not need to post every day.

افتح المصنف واقرأ البداية ثم الموجز والتقويم. توجد ٣٠ زاوية قابلة للتخصيص مع التاريخ والنص والدعوة والمسؤول والحالة. اختر المناسب ولا يلزم النشر يومياً.

## 3. Draft with the prompt library

Open 03_AI_PROMPTS_EN_AR.md. Use the campaign brief as input to one of the twelve paired prompts. Ask for a draft based only on your supplied facts and for missing information to be listed. Never paste private customer records. Review tone, translation, links and claims before approving.

استخدم أحد التوجيهات الاثني عشر باللغتين مع موجزك. اطلب صياغة مبنية على الحقائق وإظهار المعلومات الناقصة. لا تدخل بيانات عملاء خاصة وراجع النبرة والترجمة والروابط.

## 4. Build a simple campaign sequence

Choose a playbook from 04_CAMPAIGN_PLAYBOOKS.md: a new offer launch, an educational series, or an opt-in customer follow-up. Use 05_COPY_CANVAS.md to connect the problem, useful proof and one next action. Avoid invented urgency and fabricated testimonials.

اختر إطلاق عرض أو سلسلة تعليمية أو متابعة بموافقة العميل. استخدم مخطط النص لربط المشكلة بدليل مفيد وخطوة واحدة. لا تختلق ندرة أو شهادات عملاء.

## 5. Record actual measurements

In the Metrics sheet enter actual impressions, clicks, qualified inquiries, orders, revenue and spend. Calculated rates stay blank when the denominator is zero. Revenue divided by ad spend is return on ad spend, not profit. Keep campaign costs separate from product delivery costs and compare equal periods.

سجّل الأرقام الفعلية في المؤشرات. تظل النسب فارغة إذا كان المقام صفراً. عائد الإنفاق الإعلاني ليس ربحاً. افصل تكاليف الحملة عن التسليم وقارن فترات متساوية.

## 6. Review and repeat with one change

Use Experiments to write one hypothesis and choose one variable, such as the headline. Use 06_REVIEW_CHECKLIST.md before publishing and after the test. Record what happened, your uncertainty and the next action. Save a dated backup. This toolkit does not launch ads or connect accounts.

اكتب فرضية في ورقة التجارب وغيّر متغيراً واحداً مثل العنوان. استخدم قائمة المراجعة قبل النشر وبعد التجربة. سجّل النتائج وحدودها والخطوة التالية واحفظ نسخة مؤرخة.

