# Three campaign playbooks / ثلاثة أدلة للحملات

## 1. New offer launch / إطلاق عرض
Goal: help the right buyer understand a new offer.
Before starting: confirm contents, price, delivery, limitations and capacity.
Days 1–3: collect real questions; publish a useful tip tied to the problem.
Days 4–7: demonstrate one included item with a fictional or permitted example.
Days 8–10: answer the most important scope and delivery questions.
Days 11–14: invite readers to the product page with accurate terms; no invented deadline.
Review: compare product-page visits and qualified inquiries during equal windows. If people misunderstand the scope, rewrite the offer before spending more.
الخطوات: تحقق من العرض، اشرح المشكلة، اعرض عنصراً فعلياً، أجب عن الأسئلة ثم ادعُ لقراءة التفاصيل. إن لم يفهم الجمهور نطاق الخدمة، حسّن الشرح قبل زيادة الإنفاق.

## 2. Educational series / سلسلة تعليمية
Goal: answer one recurring customer question through practical examples.
Pick a problem you can demonstrate; split it into three manageable lessons.
Publish lesson 1 as a checklist, lesson 2 as a demonstration and lesson 3 as an FAQ.
Use a consistent topic and one action per post. Invite questions without requesting private data publicly.
Review saves, substantive questions and relevant clicks. High views alone do not establish buyer intent.
الخطوات: اختر سؤالاً متكرراً وقدّم قائمة عملية وعرضاً تطبيقياً وأسئلة شائعة. راقب الحفظ والأسئلة المفيدة والنقرات المناسبة، لا المشاهدات وحدها.

## 3. Requested follow-up / متابعة بموافقة العميل
Goal: deliver the reminder or information a customer requested.
Check that the request and channel are recorded and still relevant.
Verify current stock, price and offer terms. Write one personal, factual reminder.
Review before sending manually. If the person declines, record that and stop promotional follow-up.
No purchased lists, scraped contacts, automatic bulk sending or fabricated familiarity.
Review replies for usefulness, not just volume. Keep private details outside AI prompts and public worksheets.
الخطوات: تحقق من طلب المتابعة، راجع المعلومات، اكتب تذكيراً شخصياً واحداً ثم راجعه وأرسله يدوياً. احترم الرفض ولا تستخدم قوائم مشتراة أو بيانات مستخرجة دون إذن.
