# Review checklist / قائمة المراجعة

## Before publishing / قبل النشر
- One audience, one useful point and one next action.
- Prices, stock, delivery, included items and exclusions match the actual offer.
- All placeholders removed; English and Arabic reviewed separately.
- Evidence exists for factual claims; fictional examples labelled.
- Links open correctly; images and music have appropriate usage rights.
- No private customer information, fake testimonials or invented urgency.
- Budget and owner approved before any paid campaign is started elsewhere.

جمهور واضح، معلومة مفيدة ودعوة واحدة. طابق الأسعار والمحتويات والتسليم، وراجع اللغتين والروابط والحقوق. لا تنشر بيانات خاصة أو شهادات مختلقة. اعتماد الميزانية يسبق إطلاق إعلان مدفوع.

## After the test / بعد التجربة
- Record actual values, source and observation window.
- Separate clicks, qualified inquiries and confirmed orders.
- Use equal observation windows; flag small samples and tracking gaps.
- Calculate ratios only when their denominator is greater than zero.
- ROAS is revenue / ad spend, not profit or proof of causality.
- Record one learning, one uncertainty and one next change.
- Save a dated workbook copy. Archive unused experiments without erasing results.

سجّل القيم الفعلية ومصدرها والفترة. افصل النقرات والاستفسارات والطلبات. لا تحسب نسبة بمقام صفر. عائد الإعلان ليس ربحاً. سجّل تعلّماً واحداً وحدود الاستنتاج وخطوة تالية واحفظ نسخة مؤرخة.
