# Worked example / مثال مكتمل

JUST AI Content Sprint v1.0. All business names and outcomes below are fictional demonstrations. No sales or performance claim is made.
جميع الأسماء والبيانات في هذا المثال خيالية للتوضيح ولا تمثّل نتائج مبيعات.

## Brief / الموجز
Business: Cedar Desk, a fictional freelance slide-design studio.
Audience: founders preparing a short pitch deck.
Offer: a one-page slide audit checklist (hypothetical product), editable text, self-service download. Price used in the example: USD 9. No design service, investment advice or fundraising guarantee included.
Goal: get interested founders to read the product contents, not collect sensitive pitch materials in public.
القناة: حساب المشروع. الجمهور: مؤسسو مشاريع يعدّون عرضاً تقديمياً. الهدف: قراءة محتويات قائمة المراجعة قبل الشراء. السعر التجريبي 9 دولارات، دون خدمة تصميم أو ضمان تمويل.

## Seven completed English + Arabic drafts

### 1 — Problem / المشكلة — single image
EN: A busy slide can hide your strongest idea. Before adding another chart, write the one sentence your audience should remember. Use it as the slide heading. Save this for your next presentation.
AR: قد تخفي الشريحة المزدحمة فكرتك الأقوى. قبل إضافة رسم جديد، اكتب الجملة الوحيدة التي تريد أن يتذكرها الجمهور واجعلها عنوان الشريحة. احفظ النصيحة لعرضك القادم.
Visual: own screenshot of a fictional slide, no client data.

### 2 — Quick win / خطوة مفيدة — carousel
EN: Three checks before you share a deck: one message per slide, readable labels, and a source beside every external number. Start with the busiest slide today.
AR: ثلاث مراجعات قبل مشاركة العرض: فكرة واحدة لكل شريحة، وتسميات مقروءة، ومصدر لكل رقم خارجي. ابدأ اليوم بالشريحة الأكثر ازدحاماً.
Visual: three original cards; one check per card.

### 3 — Process / خلف الكواليس — short video
EN: Our slide review starts with the message, then checks the layout, and finishes with links and sources. That final pass helps catch broken references before the deck is shared.
AR: تبدأ مراجعتنا برسالة الشريحة، ثم التخطيط، وأخيراً الروابط والمصادر. تساعد الجولة الأخيرة على اكتشاف المراجع المعطلة قبل مشاركة العرض.
Visual: screen recording of fictional sample only, labelled DEMO.

### 4 — FAQ / سؤال شائع — text image
EN: Does the checklist redesign your deck? No. It gives you review steps you apply yourself. It includes a blank working checklist and a completed example. If you need a full redesign, ask about a separate service before buying.
AR: هل تعيد قائمة المراجعة تصميم عرضك؟ لا. إنها خطوات تطبّقها بنفسك، مع قائمة فارغة ومثال مكتمل. إذا احتجت إلى إعادة تصميم كاملة فاسأل عن خدمة منفصلة قبل الشراء.
Visual: two columns: included / not included.

### 5 — Demonstration / عرض تطبيقي — screen recording
EN: Here is the checklist on a fictional slide: we identified the main message, moved the source next to the chart, and rewrote the heading. This is a demonstration of the review process, not evidence of fundraising results.
AR: هذه مراجعة شريحة خيالية: حدّدنا الرسالة، ووضعنا المصدر بجانب الرسم، وأعدنا كتابة العنوان. هذا شرح للطريقة وليس دليلاً على نتائج تمويل.
Visual: before/after fictional slide, clearly labelled.

### 6 — Offer / العرض — product image
EN: Need a structured way to review your next pitch deck? Cedar Desk’s example checklist includes editable review steps and a completed example. USD 9 in this fictional offer. Self-service file download; no redesign service. Read the exact contents on the product page before buying.
AR: تحتاج إلى طريقة منظمة لمراجعة عرضك؟ تتضمن قائمة Cedar Desk التجريبية خطوات قابلة للتعديل ومثالاً مكتملاً. السعر في هذا العرض الخيالي 9 دولارات. ملف تستخدمه بنفسك، دون خدمة إعادة تصميم. راجع المحتويات الدقيقة قبل الشراء.
Visual: actual contents preview, price and delivery terms verified before real use. No invented checkout link is supplied.

### 7 — Listening / الاستماع — question card
EN: We covered message, readability and evidence this week. Which needs a deeper tutorial next: chart labels or slide headings? Please don’t post confidential deck details in comments.
AR: تناولنا الرسالة والوضوح والأدلة هذا الأسبوع. ما الذي يحتاج إلى شرح أعمق: تسميات الرسوم أم عناوين الشرائح؟ لا تنشر تفاصيل عروض سرية في التعليقات.
Visual: simple two-choice card.

## Sample review arithmetic / حساب توضيحي
Post A: 200 views, 8 saves, 2 qualified inquiries. Save rate = 8/200×100 = 4%; inquiry rate = 2/200×100 = 1%.
Post B: 80 views, 4 saves, 0 qualified inquiries. Save rate = 5%; inquiry rate = 0%.
A produced more total saves; B had a higher save rate. Neither proves sales impact. Small samples do not establish a winning strategy. Repeat with the same observation window; test one hook change next cycle.
المنشور أ: 200 مشاهدة، 8 حفظ، استفساران مؤهلان. معدل الحفظ 4% والاستفسار 1%. المنشور ب: 80 مشاهدة و4 حفظ دون استفسارات؛ الحفظ 5%. الأعداد الصغيرة لا تثبت استراتيجية ناجحة. كرّر القياس بنفس المدة وغيّر افتتاحية واحدة فقط.

## Completion check / فحص الإنجاز
All seven drafts have a purpose, asset brief and CTA. The price and product are labelled fictional. No real private data is used. For your business, replace the offer and delivery terms, assign actual dates, remove every placeholder, then review before posting.
لكل مسودة هدف وتصور بصري ودعوة واحدة. استبدل العرض وشروط التسليم وحدّد التواريخ وراجع المحتوى قبل النشر.
