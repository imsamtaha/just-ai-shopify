# Delivery acceptance checklist

This is an onboarding document, not the completed custom design.
هذا ملف بدء المشروع وليس التصميم النهائي.

- [ ] Responsive one-page design and implementation matches the agreed brief.
- [ ] Approved content and call-to-action links matches the agreed brief.
- [ ] Desktop and mobile review matches the agreed brief.
- [ ] Handover with agreed hosting arrangement matches the agreed brief.
- [ ] Spelling, contact details, URLs and languages checked.
- [ ] Files open in the agreed formats and dimensions.
- [ ] Usage rights and any third-party costs documented.
- [ ] Agreed revisions completed and handover accepted in writing.

راجع الأسماء والروابط واللغات وصيغ الملفات والحقوق والتعديلات المتفق عليها قبل قبول التسليم.
