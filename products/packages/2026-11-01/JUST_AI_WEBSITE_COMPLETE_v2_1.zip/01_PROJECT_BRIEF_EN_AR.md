# One-Page Website — project brief

Complete in English or Arabic. Send only the information needed to scope the work. Do not include passwords, payment details or private customer data.
يمكن تعبئة النموذج بالعربية أو الإنجليزية. لا ترسل كلمات مرور أو بيانات دفع أو معلومات عملاء خاصة.

## Business name, audience and one page goal
Your answer / إجابتك:

## Approved headings and body copy
Your answer / إجابتك:

## Approved logo and images with usage rights
Your answer / إجابتك:

## Call-to-action URLs and public contact details
Your answer / إجابتك:

## Required languages, domain and hosting arrangements
Your answer / إجابتك:

## Agreement record / سجل الاتفاق
Scope: 
Revision allowance: 
File formats and source handover: 
Delivery date: 
Dependencies from customer: 
Additional costs: 
Written approval: 

Leave these fields open until agreed with JUST AI before purchase.
اترك بنود الاتفاق مفتوحة حتى تأكيدها كتابياً قبل الشراء.
