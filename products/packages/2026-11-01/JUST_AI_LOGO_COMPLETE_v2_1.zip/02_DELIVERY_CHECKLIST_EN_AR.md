# Delivery acceptance checklist

This is an onboarding document, not the completed custom design.
هذا ملف بدء المشروع وليس التصميم النهائي.

- [ ] Logo and agreed colour variations matches the agreed brief.
- [ ] Colour palette and typography direction matches the agreed brief.
- [ ] Compact brand guide matches the agreed brief.
- [ ] PNG and SVG final exports matches the agreed brief.
- [ ] Spelling, contact details, URLs and languages checked.
- [ ] Files open in the agreed formats and dimensions.
- [ ] Usage rights and any third-party costs documented.
- [ ] Agreed revisions completed and handover accepted in writing.

راجع الأسماء والروابط واللغات وصيغ الملفات والحقوق والتعديلات المتفق عليها قبل قبول التسليم.
