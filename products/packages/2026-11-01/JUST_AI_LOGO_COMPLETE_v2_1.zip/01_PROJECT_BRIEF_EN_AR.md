# Logo & Brand Identity — project brief

Complete in English or Arabic. Send only the information needed to scope the work. Do not include passwords, payment details or private customer data.
يمكن تعبئة النموذج بالعربية أو الإنجليزية. لا ترسل كلمات مرور أو بيانات دفع أو معلومات عملاء خاصة.

## Exact business name and tagline
Your answer / إجابتك:

## Audience and competitors to distinguish from
Your answer / إجابتك:

## Three brand adjectives and preferred/avoided colours
Your answer / إجابتك:

## Where the logo will be used and required languages
Your answer / إجابتك:

## Existing assets you own and examples with context
Your answer / إجابتك:

## Agreement record / سجل الاتفاق
Scope: 
Revision allowance: 
File formats and source handover: 
Delivery date: 
Dependencies from customer: 
Additional costs: 
Written approval: 

Leave these fields open until agreed with JUST AI before purchase.
اترك بنود الاتفاق مفتوحة حتى تأكيدها كتابياً قبل الشراء.
